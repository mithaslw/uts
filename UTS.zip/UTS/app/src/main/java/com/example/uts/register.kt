package com.example.uts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import kotlinx.android.synthetic.main.activity_register.*

class register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        btnRegisterListener()
    }
    private fun btnRegisterListener(){
        btn_2.setOnClickListener {
            startActivity(Intent(this, ContactsContract.Profile::class.java ))
        }
    }
}
